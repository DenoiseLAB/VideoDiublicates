http://195.2.70.5/ideo_compare/ - небольшое сделаное АПИ.

EDA_video_v01_v02.ipynb - файл Еxploration Data Analysis + Векторная база данных Milvus + Resnet

Phash_v01.ipynb - Модель сравнения поиска видео по алгоритму pHash

Хакатон_Дубликаты_v11.ipynb - > 20 алгоритмов сравнения и препроцессинга видео + KAN

Дубликаты_видео_v01.pptx - Презентация

